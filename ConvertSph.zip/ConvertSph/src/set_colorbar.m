function set_colorbar(hcb,hcbtitle,cmax,cmin,ntick,fontsize,titleflag)
y_format='%3.1f';

my_handle=hcb;
if(titleflag=='V')
set(get(my_handle,'Title'),'string',hcbtitle,'fontsize',fontsize);
elseif(titleflag=='H')
my_handle.Label.String = hcbtitle;
end
set(my_handle,'ytick',[]);
caxis([cmin cmax]);
dc=(cmax-cmin)/(ntick-1);
ytick =zeros(ntick,1);
for i= 1:ntick
    %         yticklabel{kkk}=sprintf(y_format,cmin+dc*(kkk-1));
    %         ytick(kkk) =str2num(yticklabel{kkk});
    ytick(i,1) =  cmin+dc*(i-1); %str2num(yticklabel{kkk});
end
 
set(my_handle,'ytick',ytick(:));
ytick=get(my_handle,'ytick');

for i = 1:ntick
    yticklabel{i}=sprintf(y_format,cmin+dc*(i-1));
end
set(my_handle,'yticklabel',yticklabel);

% poshc=get(my_handle,'pos')
% 
%  
%  set(my_handle,'pos',poshc);
 