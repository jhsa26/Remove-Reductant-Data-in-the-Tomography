
% function of 2-D beamforming analysis with azimuth and slowness

function [beam, powerbeam] = beamform2Dfreq(x,y,azi,s,fdata,fc,iuni,offdiag)
% Usage: 
% [beam, powerbeam] = beamform2Dfreq(x,y,azi,s,fdata,fc,iuni,offdiag) 
%       (if offdiag = 1)
% beam = beamform2Dfreq(x,y,azi,s,fdata,fc,iuni,offdiag) 
%       (if offdiag ~= 1) 
% 
% x: x(1,nsta)  (vector of x-coordinate for nsta stations)
% y: y(1,nsta)  (vector of y-coordinate for nsta stations)
% azi: azi(1,ndeg) (vector of angles in degree for beamforming)
% s: s(1,ns) (vector of slowness in sec/km for beamforming)
% fdata: fdata(nsta,nf)  (matrix of input spetrum matrix for nsta stations 
%                       and nf frequency points, nf = length(fc) )
% fs: scalar (sampling frequency for input traces)
% fc: fc(1,nf) (input central frequency vector for beamforming)
% iuni: scalar (=1, using average amplitude of spetrum at each frequency
%                  for beamforming; 
%               =2, set the amplitude to be zero for those wield large and 
%                  small amplitude (out of 2.5*std); 
%               =0, using real spetrum amplitude of each trace)
% offdiag: (=1, performing off-diagonal beamforming to estimate signal
%               power; others: normal cross-spectral density matrix
%               beamforming)
% 
% output:
% beam: beam(ns,ndeg,nf) (output beamformer power)
% powerbeam: beam(ns,ndeg,nf) (the signal power estimated from off-diagonal 
%            beamforming, if offdiag = 1)

% written by Huajian Yao
% Last Modified: Jan 29 2011

%%
nsta = length(x); % number of stations
naz = length(azi); % number of azimuth vector az(1,naz) in degree
ns = length(s);  % number of slowness vector s(1,ns) in unit s/km
azrad = azi*pi/180; % degree to radian
coord = [x; y]; % (x,y) coordinate of stations, coord(2,nsta)
sproj_x = s'*sin(azrad);  % slowness projection on x-coord. of stations
sproj_y = s'*cos(azrad);  % slowness projection on y-coord. of stations
 
nf = length(fc); % number of frequencies for beamforming

%% beamforming for each single frequency
beam = zeros(ns,naz,nf);
powerbeam = zeros(ns,naz,nf);

for mfpt = 1:nf
    freq = fc(mfpt);  % selected frequency
    fslice = fdata(:,mfpt); % spectrum at selected frequency     
    SpectrAmp = abs(fslice);
    
    neffsta =  nsta;
    
    switch iuni
        case 0  %using the real amplitude of all traces
            neffsta = nsta;
        case 1  % normalize the amplitude of spetrum using the median amplitude
            medianAmp = median(SpectrAmp);
            fslice = medianAmp*fslice./abs(fslice);
            neffsta = nsta;
        case 2  % set the spetrum amplitude to zero for weird large and small amplitude
            meanAmp = mean(SpectrAmp);
            stdAmp = std(SpectrAmp);  
            JJ = (SpectrAmp > (meanAmp + 3*stdAmp)); % first remove wield large ones: out of mean + 3*std
            meanAmp = mean(SpectrAmp(~JJ)); % then calculate new mean and std
            stdAmp = std(SpectrAmp(~JJ));
            % then find new wield large and small ones: out of 2*std
            KK = find(abs(SpectrAmp - meanAmp) > 2*stdAmp);
            fslice(KK) = 0; % set the spectrum of these wield stations to be zero
            neffsta = nsta - length(KK);
            clear II JJ KK
    end

    stseis2 = zeros(ns, naz);
    omega = 2*pi*freq; % center frequency
    for kk = 1:nsta
        delt2 = sproj_x*coord(1,kk) + sproj_y*coord(2,kk);   % slowness*r
        fts2 = complex(cos(-omega*delt2), sin(-omega*delt2));
        sseis2 = conj(fslice(kk))*fts2;
        stseis2 = stseis2 + sseis2;
    end
    stseis2 = abs(stseis2).^2/neffsta;
    beam(:,:,mfpt) = stseis2;
    
    if offdiag == 1
        meanPower = sum(abs(fslice).^2)/neffsta;
        powerbeam(:,:,mfpt) = (beam(:,:,mfpt) - meanPower)/(neffsta-1);
    end
end
        


