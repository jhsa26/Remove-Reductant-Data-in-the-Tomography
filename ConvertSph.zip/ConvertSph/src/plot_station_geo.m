function plot_station_geo(X,Y,name)
figure;
fig_x0=2;
fig_y0=2;
set(gcf,'PaperPositionMode','auto')
set(gcf,'units','centimeters')
set(gcf,'pos',[fig_x0 fig_y0 10 10])
set(gca,'units','centimeters')
set(gca,'units','centimeters')
set(gca,'pos',[ 2  3       6 6]);

plot(X,Y,'k^','markersize',10,'markerfacecolor','k')
xlabel('X(km)','fontsize',10)
ylabel('Y(km)','fontsize',10)
set(gca,'linewidth',1.25,'fontsize',18)
% xlim([min(X)-5 max(X)+5])
% ylim([min(Y)-5 max(Y)+5])
% xlim([min(X)-0.2 max(X)+0.2])
% ylim([min(Y)-0.2 max(Y)+0.2])
xlim([min(X)-2 max(X)+2])
ylim([min(Y)-2 max(Y)+2])
% xlim([-15 15])
% ylim([-15 15])
axis equal
print(gcf,'-depsc2',['./Figures/',name,'.eps']);
print(gcf,'-djpeg','-r300',['./Figures/',name,'.jpg']);