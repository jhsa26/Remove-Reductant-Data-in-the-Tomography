function EnergyMap=plotEnergyMap_polar(EnergyMap,freq,slow,baz,baz0,slow0,add_polar,indexAlpha)
% usage
% we only change those parameters which can be used to change the
% configuration of subplots.
% dhight,dwidth >>  control the subplot size,corresponding the height and width of subplot
% xpos1, ypos1 >> control  origin of  the first subplot when starting to plot the first subplot from the bottom in figure
% Horspac,Verspac >> control the Horizontal spacing and Vertical spacing of each pair of subplots
% crbspac,                 >> control the distance from subplot to  corresponding  colorbar
% fontsize  >> control the fontsize of all subplots  in one figure.
% fig_x0,fig_y0>> control the origin of the figure

% note that we can change the Fontsize , Dhight,Dwidth, Horspac,Verspac and
%                    Crbspac to satisfy our needs.
color_name='y';
fontsize=10;
linewidth=1.25;
slox = slow0.*sind(baz0);    sloy = slow0.*cosd(baz0);
minslow=-slow(end);          maxslow=slow(end);

figure;
set(gcf,'PaperPositionMode','auto')
set(gcf,'units','centimeters')

HorPics =1;
VerPics=1;
dhight = 4.8;
dwidth = 6;

% dhight = 6;
% dwidth = 8;

xpos1 = 2;
ypos1 = 3;
% Horspac =2.5;%cm
% Verspac=  1.1;%cm
Horspac =0.1;%cm
Verspac=  1;%cm
crbspac = 0.8; % colorbar spacing cm%
fig_x0=2;
fig_y0=2;
fig_hight=ypos1+(VerPics-1)*Verspac+VerPics*dhight+1;
fig_width= xpos1+(HorPics -1)*Horspac +HorPics *dwidth+2;


set(gcf,'pos',[fig_x0 fig_y0 fig_width fig_hight])

EnergyMap = EnergyMap./max(max(EnergyMap));
EnergyMap = 20*log10(EnergyMap+eps);
maxE= max(max(EnergyMap));
[P,R] = meshgrid(90-baz,slow);
[xx ,yy] = pol2cart((P/360)*2*pi,R);
% xxinter=interp2(xx,2);
% yyinter=interp2(yy,2);
% zzinter = interp2(EnergyMap,2);
% xx = xxinter;
% yy = yyinter;
% EnergyMap = zzinter;
%% plot EngerMap
haxes=axes;
set(gca,'units','centimeters')
set(haxes,'pos',[ xpos1  ypos1       dwidth    dhight]);
colorMap=colormap(parula); %pink
% colormap(haxes,flipud(colorMap));
pcolor(haxes,xx,yy,EnergyMap);
hold on
shading flat

hb2=colorbar(haxes,'southoutside');
set(hb2,'unit','centimeters')
poshc=get(hb2,'pos');
set(hb2,'location','manual');
% poshc(1)=poshc(1)+crbspac;
% poshc(1)=poshc(1)-3.5*crbspac;
temp = poshc(3)*0.7; dintervel = (poshc(3)-temp)/2;
poshc(3)=temp;
poshc(2)=poshc(2)-2.5*crbspac;
poshc(1) = poshc(1)+dintervel;
set(hb2,'pos',poshc);
% set(hb2,'location','manual');
%         set(get(hb2,'title'),'string','Power', 'fontsize',fontsize)
hcbtitle='Relative power(dB)';
cmax = 0;   % max(max(EnergyMap));
cmin = -20; %min(min(EnergyMap));
ntick=5;
set_colorbar(hb2,hcbtitle,cmax,cmin,ntick,fontsize,'H')

hold on
plot(haxes,slox,sloy,'sr','markersize',6)
% text(  minslow-0.03,maxslow,indexAlpha,...
%     'fontsize',fontsize,'color','k','fontweight','bold')
text(  -0.03,maxslow-0.06,[ num2str(freq) 'Hz'],...
    'fontsize',fontsize,'color',color_name,'fontweight','bold')
axis square

%% add polar plot
if add_polar
    
    hand_ax = haxes;
    ang = 0:45:360;
    sln=(0:0.1:maxslow);
    ns=length(sln);
    for i = 1:length(ang)
        hpolar1=polar(hand_ax, ang(i)/180*pi*ones(1,ns), sln, 'r--');
        set( hpolar1,'linewidth',linewidth-0.95)
        hold on;
    end
    sgrid = 0.1:0.1:max(sln);
    azi=0:3:360;
    naz=length(azi);
    for i = 1:length(sgrid)
        hpolar2 = polar(hand_ax,azi/180*pi, sgrid(i)*ones(1, naz), 'r--');
        set(hpolar2,'linewidth',linewidth-0.95)
        hold on;
    end
    axes(hand_ax)
    box(gca,'on')
    %plot slowness label
    temp_laby=(sgrid-0.01).*cosd(136);
    temp_labx=(sgrid-0.01).*sind(136);
    for kkk=1:length(sgrid)
        text(  temp_labx(kkk)-0.01,temp_laby(kkk)+0.01,num2str(sgrid(kkk)),'fontsize',10,'color',color_name,'rotation',45)
    end
    %plot degree label
    for kkk=1:length(ang)-1
        inx=0.04;
        switch ang(kkk)
            case 0
                deg=357;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation =0;
            case 45
                deg=42;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation=-45;
            case 90
                deg=87;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation=-90;
            case  135
                rotation=45;
                deg=142;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
            case 180
                deg=187;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation =0;
            case 225
                deg=232;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation=-45;
            case 270
                deg=278;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation=-90;
            case 315
                deg=308;
                temp_laby=(sgrid(end)+inx)*cosd(deg);
                temp_labx=(sgrid(end)+inx)*sind(deg);
                rotation=45;
        end
        
        
        text(  temp_labx,temp_laby,[num2str(ang(kkk)) '^o'],'fontsize',10,'color','k','rotation',rotation)
        
    end
    temp_laby=(0.05).*cosd(165);
    temp_labx=(0.05).*sind(165);
    text(  temp_labx,temp_laby,'Slowness (s/km)','fontsize',7,'color',color_name,'rotation',-45)
    % endplot label
    
    text(  minslow,0,'W','fontsize',fontsize,'color',color_name)
    text( maxslow-0.025,0,'E','fontsize',fontsize,'color',color_name)
    text(  -0.015,maxslow-0.02,'N','fontsize',fontsize,'color',color_name)
    text(  -0.015,minslow+0.025,'S','fontsize',fontsize,'color',color_name)
    axis tight square
    axis off
end
%%
h=findobj(gcf,'type','axes');
set(h,'fontsize',fontsize,'linewidth',linewidth)
hold off
return



