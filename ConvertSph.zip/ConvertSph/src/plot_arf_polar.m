function plot_arf_polar(stax,stay,fctest,sln,baz,name)
x=stax';
y=stay';
nsta = length(x);

angtest = 0;

slntest = zeros(length(angtest),1);

srcamp = 1*ones(length(baz),1);

noiseamp = 0.0;

bazitest = angtest*pi/180; % degree to rad
nsrc = length(bazitest);
nfctest=length(fctest);
fdata=zeros(nsta,nfctest);
for mfpt = 1:nfctest
    w = 2*pi*fctest(mfpt);
    for i = 1:nsta
        for k = 1:nsrc
            dt = (x(i)*sin(bazitest(k))+y(i)*cos(bazitest(k)))*slntest(k);
            fdata(i, mfpt) = fdata(i, mfpt) + srcamp(k)*complex(cos(-w*dt),sin(-w*dt));
        end
        % add random noise of the spectrum
        randvalue = rand(1,1);      % between [0 1]
        randtheta = randvalue*2*pi; % between [0 2*i]
        fdata(i, mfpt) = fdata(i, mfpt) + noiseamp*complex(cos(randtheta),sin(randtheta));
    end
end
%% beamforming analysis

[rawbeam,~] = beamform2Dfreq(x,y,baz,sln,fdata,fctest,0,1);
beam_energy= rawbeam;

for itest=1:nfctest
    EnergyMap = beam_energy(:,:,itest);
    freq = fctest(itest);
    plotEnergyMap_polar(EnergyMap,freq,sln,baz,bazitest,slntest,1,'(a)');
    
    print(gcf,'-depsc2',['./Figures/',name,'_',num2str(freq),'_Hz_' 'ARF','.eps']);
    print(gcf,'-djpeg','-r300',['./Figures/',name,'_',num2str(freq),'_Hz_','ARF','.jpg']);
end