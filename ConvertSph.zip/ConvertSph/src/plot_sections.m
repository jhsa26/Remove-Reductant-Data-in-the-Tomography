function plot_sections(baz,slow,baz0,slow0,energymap,titlename)
fontsize=10;
width=1.5;
markersize=5;
fig_x0=2;
fig_y0=2;
fig_width=15;
fig_hight=6;
figure;
set(gcf,'PaperPositionMode','auto')
set(gcf,'units','centimeters')
set(gcf,'pos',[fig_x0 fig_y0 fig_width fig_hight])
subplot(1,2,1)
for i=1:size(energymap,1)
    plot(baz,energymap(i,:),'-r','linewidth',width)
    hold on
    plot(baz0,zeros(1,length(baz0)),'go','markersize',markersize,'markerfacecolor','g')
end

ylim([-20 0])
xlim([baz(1) baz(end)])
xlabel('Backazimuth (Degreee)','fontsize',fontsize)
ylabel('Relative power(dB)','fontsize',fontsize)
% title(titlename,'fontsize',fontsize)
set(gca,'fontsize',fontsize,'linewidth',width)


subplot(1,2,2)
for i=1:size(energymap,2)
    plot(slow,energymap(:,i),'-r','linewidth',width)
    hold on
    plot(slow0,zeros(1,length(slow0)),'go','markersize',markersize,'markerfacecolor','g')
end

xlim([slow(1) slow(end)])
ylim([-20 0])
xlabel('Slowness (s/km)','fontsize',fontsize)
ylabel('Relative power(dB)','fontsize',fontsize)
% title(titlename,'fontsize',fontsize)
set(gca,'fontsize',fontsize,'linewidth',width)
end