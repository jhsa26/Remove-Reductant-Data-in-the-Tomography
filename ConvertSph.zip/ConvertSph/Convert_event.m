clc
close all
clear all
addpath('geomap/');addpath('src/')
close all
wlat_ft=33.5528;   % orig
wlon_ft=-116.5833; % orig,  0 km depth  fixed in there
rota=43*pi/180;
%xmin=-105;
%xmax=160;
%ymin=-55;
%ymax=105;
count=0;
if 1
    fid=fopen('event.dat');
    fid_car=fopen('event.car','w');
    while ~feof(fid)
        count=count+1
        line=fgetl(fid);
        %    disp(line)
        temp=strsplit(strtrim(line));
        staname=temp{15};
        lat_ft=str2num(temp{8});
        lon_ft=str2num(temp{9});
        dep_ft=str2num(temp{10});
        mag=temp{11};
        evid = temp{15};
        [x,y,z]=sph2car_ft(lat_ft,lon_ft, 0,wlat_ft,wlon_ft, rota);
%        if (x>=xmin && x<=xmax) && (y>=ymin && y<=ymax)
            fprintf(fid_car,'%s  %10.6f %10.6f %10.6f  %10.6f %10.6f %s\n',evid,lat_ft,lon_ft,dep_ft,x,y,mag);
%        end
    end
    fclose(fid_car);
    return
end

evpos=load('event.car');
plot(evpos(:,5),evpos(:,6),'.')

