# ConvertSph2Car
Those codes are used to make transformation between  Cartesian coordinate system and  Spherical coordinate system . If you have  stations' longitudes and latitudes , and want to show them in Cartesian coordinate system, so you should choose a reference point or reference station before converting coordinate.
